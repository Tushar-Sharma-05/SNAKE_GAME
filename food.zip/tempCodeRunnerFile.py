screen.onkey(snake.left, "Left")
# screen.onkey(snake.right, "Right")